
        <div class="content-bottom-widgets">
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <div class="widget widget_text">
                            <div class="textwidget">
                                <img src="../assets/viewtech/images/logo-ft-1.jpg" alt="image">
                            </div>
                        </div><!-- /.widget_text -->
                    </div><!-- /.col-md-4 -->

                    <div class="col-md-8">
                        <div class="subscrbe-form">
                            <label>Subscribe now to get daily updates</label>
                            <form class="sub-form">
                                <input type="text" class="subscrbe-field" placeholder="Your email address">
                                <input type="submit" class="subscrbe-submit">
                            </form>
                        </div><!-- /.widget_search -->
                    </div><!-- /.col-md-8 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div><!-- /.content-bottom-widgets -->