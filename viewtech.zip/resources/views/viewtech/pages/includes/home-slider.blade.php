            <!-- Slider -->
            <div class="tp-banner-container">
                <div class="tp-banner">
                    <ul>
                        <li data-transition="random-static" data-slotamount="7" data-masterspeed="1000" data-saveperformance="on">
                            <img src="../assets/viewtech/images/slides/1.jpg" alt="slider-image" />
                            <div class="tp-caption sfl title-slide center" data-x="30" data-y="147" data-speed="1000" data-start="1000" data-easing="Power3.easeInOut">                            
                                Decoration &amp; Furniture<br><span>Living Room</span>
                            </div>  
                            <div class="tp-caption sfr desc-slide center" data-x="30" data-y="249" data-speed="1000" data-start="1500" data-easing="Power3.easeInOut">                       
                                We offer home furniture in a variety of styles for every room in<br>your house home decorators collection.
                            </div>    
                            <div class="tp-caption sfl flat-button-slider style2" data-x="30" data-y="333" data-speed="1000" data-start="2000" data-easing="Power3.easeInOut"><a href="#">Read more</a></div>

                            <div class="tp-caption sfr border-bottom" data-x="222" data-y="344" data-speed="1000" data-start="2000" data-easing="Power3.easeInOut"><a href="/services">Our Services</a></div>                        
                        </li>

                        <li data-transition="random-static" data-slotamount="7" data-masterspeed="1000" data-saveperformance="on">
                            <img src="../assets/viewtech/images/slides/2.jpg" alt="slider-image" />
                            <div class="tp-caption sfl title-slide center" data-x="30" data-y="147" data-speed="1000" data-start="1000" data-easing="Power3.easeInOut">                            
                                <span>Interior Design Solutions</span>
                            </div>  
                            <div class="tp-caption sfr desc-slide center" data-x="30" data-y="209" data-speed="1000" data-start="1500" data-easing="Power3.easeInOut">                       
                                HnK’s design solutions use space, color, materials, energy and<br>light as tools to create healthy environments that enhance<br>performance.
                            </div>    
                            <div class="tp-caption sfl flat-button-slider style2" data-x="30" data-y="320" data-speed="1000" data-start="2000" data-easing="Power3.easeInOut"><a href="#">Read more</a></div>

                            <div class="tp-caption sfr border-bottom" data-x="222" data-y="331" data-speed="1000" data-start="2000" data-easing="Power3.easeInOut"><a href="/services">Our Services</a></div>                        
                        </li>

                        <li data-transition="slidedown" data-slotamount="7" data-masterspeed="1000" data-saveperformance="on">
                            <img src="../assets/viewtech/images/slides/3.jpg" alt="slider-image" />
                            <div class="tp-caption sfl title-slide center" data-x="30" data-y="147" data-speed="1000" data-start="1000" data-easing="Power3.easeInOut">                            
                                Landscape Design <span>For Front<br>Yards and Backyards</span>
                            </div>  
                            <div class="tp-caption sfr desc-slide center" data-x="30" data-y="249" data-speed="1000" data-start="1500" data-easing="Power3.easeInOut">                       
                                Find landscaping design ideas to increase curb appeal and home<br>value, and turn your yard into a place for relaxing.
                            </div>    
                            <div class="tp-caption sfl flat-button-slider style2" data-x="30" data-y="333" data-speed="1000" data-start="2000" data-easing="Power3.easeInOut"><a href="#">Read more</a></div>

                            <div class="tp-caption sfr border-bottom" data-x="222" data-y="344" data-speed="1000" data-start="2000" data-easing="Power3.easeInOut"><a href="/services">Our Services</a></div>                            
                        </li>
                    </ul>
                </div>
            </div>